<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
.ivu-tabs-bar{
	padding: 0;
	margin: 0;
}
.ivu-tabs-nav-scroll{
		padding-left: 250px;
	}
	.ivu-tabs-bar{
		border: none;
		height: 72px;
		background: linear-gradient(to right,rgb(41,69,203),rgb(55,152,254));
	}
	.ivu-tabs-nav .ivu-tabs-tab{
		height: 72px;
		line-height: 72px;
		font-size: 16px;
		padding: 0 20px;
		color: #FFFFFF;
	}
	.ivu-tabs .ivu-tabs-tabpane{
		min-height: 800px;
	}
	.ivu-menu-submenu{
		min-height:90vh;
	}
	.ivu-menu-item{
		font-size: 12px;
	}
</style>
