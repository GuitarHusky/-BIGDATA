import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import one from '@/views/one'
import two from '@/views/two'  
import three from '@/views/three'  
import for1 from '@/views/for'  

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect:'/p/one',
      name: 'HelloWorld',
      component: HelloWorld
    },{
    	path:'/p',
    	component:HelloWorld,
    	children:[{
    		path: 'one',
    		name: 'one',
     	  component: one
    	},{
    		path: 'two',
    		name: 'two',
     	  component: two
    	},{
    		path: 'three',
    		name: 'three',
     	  component: three
    	},{
    		path: 'for',
    		name: 'for',
     	  component: for1
    	}]
    }
  ]
})
