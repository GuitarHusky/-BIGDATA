<style scoped>

</style>
<template>
	<div class="layout">
		<Tabs value="name1" :animated='false' style="position: relative;">
			<div style="position: absolute;top: 0;left: 0;color: #FFFFFF;line-height:15px;font-size: 16px;font-weight: bold;padding-left: 20px;">
				<img src="../assets/logofff.png" alt="" style="float: left;display: inline-block;height: 40px;width: 35px;margin-top: 16px;" />
				<span style="float: left;padding-left: 10px;margin-top: 25px;">
				<span>嘉农云大数据平台</span><br />
				<span style="font-size: 12px;padding: 0;">Jia Nong</span>
				</span>
			</div>
			<TabPane label="概况" name="name1">
				<div class="layout-content">
					<Row>
						<Col span="2">
						<Menu width="auto" active-name="1-1" :open-names="['1','2','3','4']">
							<Submenu name="1">
								<template slot="title">
									<Icon type="ios-navigate"></Icon>
									概况
								</template>
								<router-link to='/p/one' style='color: #333;'>
									<MenuItem name="1-1">整体趋势</MenuItem>
								</router-link>
								<router-link to='/p/two' style='color: #333;'>
									<MenuItem name="1-2">下载量</MenuItem>
								</router-link>
								<MenuItem name="1-3">下载量分析</MenuItem>
								<MenuItem name="1-4">用户签到分析</MenuItem>
							</Submenu>
						</Menu>
						</Col>
						<Col span="22">
						<router-view></router-view>
						</Col>
					</Row>
				</div>
			</TabPane>
			<TabPane label="用户分析" name="name2">
				<div class="layout-content">
					<Row>
						<Col span="2">
						<Menu width="auto" active-name="1-1" :open-names="['1','2','3','4']">
							<Submenu name="1">
								<template slot="title">
									<Icon type="ios-navigate"></Icon>
									概况222
								</template>
								<router-link to='/p/three' style='color: #333;'>
									<MenuItem name="1-1">整体趋势222</MenuItem>
								</router-link>
								<router-link to='/p/for' style='color: #333;'>
									<MenuItem name="1-2">下载量222</MenuItem>
								</router-link>
								<MenuItem name="1-3">下载量分析222</MenuItem>
								<MenuItem name="1-4">用户签到分析</MenuItem>
							</Submenu>
						</Menu>
						</Col>
						<Col span="22">
						<router-view></router-view>
						</Col>
					</Row>
				</div>
			</TabPane>
			<TabPane label="抓取蛋价信息" name="name3">标签三的内容</TabPane>
		</Tabs>
	</div>
</template>
<script>
	export default {
		components: {

		},
		methods: {

		}
	}
</script>